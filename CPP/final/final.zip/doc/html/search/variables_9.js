var searchData=
[
  ['things_5f',['things_',['../classWidget.html#aca7acb1186919e8726d543ae4019d51c',1,'Widget']]]
];
