var searchData=
[
  ['name_5f',['name_',['../classWidget.html#a1d2f74810f3f912270a681e0671a7a55',1,'Widget']]],
  ['node',['Node',['../output_8txt.html#aa47ec68c0652f755ad9c3b276dc1b12f',1,'output.txt']]],
  ['nums',['NUMS',['../lambda_8cpp.html#a7ec633a0f8a8cc23bc9e937522d74277',1,'lambda.cpp']]]
];
