var searchData=
[
  ['widget',['Widget',['../classWidget.html#a7c125a1d1abbc8036c13546a4d3613bc',1,'Widget']]]
];
