var searchData=
[
  ['widget_2ecpp',['widget.cpp',['../widget_8cpp.html',1,'']]],
  ['widget_2eh',['widget.h',['../widget_8h.html',1,'']]]
];
