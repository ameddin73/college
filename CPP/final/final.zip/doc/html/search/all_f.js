var searchData=
[
  ['widget',['Widget',['../classWidget.html',1,'Widget'],['../classWidget.html#a7c125a1d1abbc8036c13546a4d3613bc',1,'Widget::Widget()']]],
  ['widget_2ecpp',['widget.cpp',['../widget_8cpp.html',1,'']]],
  ['widget_2eh',['widget.h',['../widget_8h.html',1,'']]]
];
