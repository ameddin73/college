var searchData=
[
  ['fizzbuzz',['FizzBuzz',['../classFizzBuzz.html',1,'']]]
];
