var searchData=
[
  ['empty',['empty',['../classBST.html#a87d4bde53c8d9761910634a71d8c77b5',1,'BST']]]
];
