var searchData=
[
  ['widget',['Widget',['../classWidget.html',1,'']]]
];
