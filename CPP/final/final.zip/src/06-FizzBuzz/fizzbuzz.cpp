#include "fizzbuzz.h"
#include <iostream>

using std::boolalpha;
using std::cout;
using std::endl;
using std::string;
using std::ostream;

FizzBuzz::FizzBuzz() :
        i_{100},
        c_{'z'},
        d_{111.11},
        s_{"null"},
        b_{true} {
    cout << "Ctor 0 called: " << endl;
}

FizzBuzz::FizzBuzz(int i) :
        i_{i},
        c_{'x'},
        d_{999.99},
        s_{"dummy"},
        b_{false} {
    cout << "Ctor 1 called: " << endl;
}

FizzBuzz::FizzBuzz(int i, char c) :
        i_{i},
        c_{c},
        d_{9001.1},
        s_{"none"},
        b_{true} {
    cout << "Ctor 2 called: " << endl;
}

FizzBuzz::FizzBuzz(int i, char c, double d) :
        i_{i},
        c_{c},
        d_{d},
        s_{"empty"},
        b_{false} {
    cout << "Ctor 3 called: " << endl;
}

FizzBuzz::FizzBuzz(int i, char c, double d, const string &s) :
        i_{i},
        c_{c},
        d_{d},
        s_{s},
        b_{true} {
    cout << "Ctor 4 called: " << endl;
}

FizzBuzz::FizzBuzz(int i, char c, double d, const string &s, bool b) :
        i_{i},
        c_{c},
        d_{d},
        s_{s},
        b_{b} {
    cout << "Ctor 5 called: " << endl;
}

ostream &operator<<(ostream &os, const FizzBuzz &fb) {
    return os << fb.i_ << ", " << fb.c_ << ", " << fb.d_ << ", " <<
              fb.s_ << ", " << boolalpha << fb.b_;
}
