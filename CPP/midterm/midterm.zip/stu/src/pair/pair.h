#ifndef PAIR_H
#define PAIR_H

#include <iostream>

using std::ostream;

// A class that holds two integers as a pair.
class Pair {
public:
    /**
     * Initialize the pair.
     *
     * @param first first value
     * @param second second value
     */
    Pair(int first, int second) :
            first_(first),
            second_(second) {
    }

    /**
     * Get the first value in pair.
     *
     * @return first value
     */
    int first() const { return first_; }

    /**
     * Get the second value in pair.
     *
     * @return second value
     */
    int second() const { return second_; }

    /**
     * Find out how many times combine has been called
     *
     * @return number of times combine was called
     */
    int num_combines() const { return num_combines_; }

    /**
     * Change the pair's first value.
     *
     * @param val new first value
     */
    void first(int val) { first_ = val; }

    /**
     * Change the pair's second value.
     *
     * @param val
     */
    void second(int val) { second_ = val; }

    /**
     * Get the sum of adding the first and second values to each other.
     *
     * @return sum of first and second value
     */
    int sum() const { return first_ + second_; }

    /**
     * Sum the first and second values and set both to the sum.
     */
    void combine() {
        ++num_combines_;
        int val = sum();
        first_ = second_ = val;
    }

    /**
     * Tells whether the first value is less than the second
     *
     * @return first value less than second?
     */
    bool less() const { return first_ < second_; }

    /**
     * The pair is printed to the ostream as "(first, second)".
     *
     * @param os the ostream to insert into
     * @param p the pair
     * @return the same ostream that was passed in
     */
    friend ostream& operator<<(ostream& os, const Pair & p) {
        return os << "(" << p.first() << ", " << p.second() << ")";
    }

private:
    /** counts the total number of pairs created */
    static int num_combines_;
    /** the first value */
    int first_;
    /** the second value */
    int second_;
}; // Pair

// initialize the static combine counter
int Pair::num_combines_ = 0;

#endif // PAIR_H
