var searchData=
[
  ['change_5fgear',['change_gear',['../classritcs_1_1_bike.html#a0500c0debb7526c6762db5b691d4c88f',1,'ritcs::Bike']]]
];
