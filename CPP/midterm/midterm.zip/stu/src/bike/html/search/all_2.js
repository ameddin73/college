var searchData=
[
  ['gear',['gear',['../classritcs_1_1_bike.html#ae9cf33436449e72822637b5ed4c69996',1,'ritcs::Bike']]]
];
