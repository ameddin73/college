var searchData=
[
  ['speed',['speed',['../classritcs_1_1_bike.html#aab310b0c24f307ec722b851d4a94a53a',1,'ritcs::Bike']]]
];
