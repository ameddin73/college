var searchData=
[
  ['ritcs',['ritcs',['../namespaceritcs.html',1,'']]]
];
