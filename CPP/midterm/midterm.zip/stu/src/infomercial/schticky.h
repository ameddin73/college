#ifndef SCHTICKY_H
#define SCHTICKY_H

#include "crap.h"

/**
 * It's the Schticky!
 *
 * https://www.youtube.com/watch?v=VAQjF5RPgbg
 */
class Schticky {
};

#endif // SCHTICKY_H
